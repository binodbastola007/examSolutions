'use client';

import React, { useState } from 'react';
import { Formik, Form, Field, resetForm } from 'formik';
import '../styles/test.css';
import { Table } from 'antd';
import { Input, Space } from 'antd';
const { Search } = Input;

const index = () => {

  const [dataSource, setDataSource] = useState([]);
  const [search, setSearch] = useState('');
  const [newDataSource, setNewDataSource] = useState('');

  const handleRegister = async (values) => {

    setDataSource((prev) => [...prev, values]);

  }

  const handleSearch = (searchString) => {
    if (searchString === '') {
      setNewDataSource('');
    }
    setSearch(searchString);
    dataSource.map((item) => {
      if (item.firstName === searchString) {
        setNewDataSource((prev) => [...prev, item]);
      }
    })
  }

  const genderDiv = {
    display: 'flex',
    displayDirection: 'column',
    fontSize: '0.8rem'
  }

  const columns = [
    {
      title: 'First Name',
      dataIndex: 'firstName',
      key: 'firstName',
    },
    {
      title: 'LastName',
      dataIndex: 'lastName',
      key: 'lastName',
    },
    {
      title: 'Age',
      dataIndex: 'age',
      key: 'age',
    },
    {
      title: 'Date of birth',
      dataIndex: 'DOB',
      key: 'DOB',
    },
    {
      title: 'Phone number',
      dataIndex: 'phoneNumber',
      key: 'phoneNumber',
    },
    {
      title: 'Gender',
      dataIndex: 'gender',
      key: 'gender',
    },
  ];


  return (
    <>
      <div className='body'>
        <div className='registerBox' >
          <h1>Sign Up</h1>
          <Formik
            initialValues={{
              firstName: '',
              lastName: '',
              age: '',
              DOB: '',
              phoneNumber: '',
              gender: ''
            }}
            onSubmit={(values, { resetForm }) => {
              handleRegister(values);
              resetForm();
            }}
          >
            {({ errors, touched }) => (
              <Form className='form' >

                <Field placeholder="Firstname" name="firstName" />

                <Field placeholder="Lastname" name="lastName" />

                <Field placeholder="Enter your age" name="age" />

                <Field placeholder="Enter your date of birth" name="DOB" />

                <Field placeholder="Enter your phone number" name="phoneNumber" />



                <p style={{ fontSize: '0.9rem' }}>Choose your gender</p>
                <div style={genderDiv}>
                  <Field type="radio" name="gender" value="male" />
                  <label>Male </label>
                  <Field type="radio" name="gender" value="female" />
                  <label>Female</label>
                </div>



                <button className='submitBtn' type="submit" >Submit</button>
              </Form>
            )}
          </Formik>
        </div>
        <div>
          <Search
            style={{ width: '115%' }}
            placeholder="Enter first name as  search text"
            allowClear
            enterButton="Search"
            size="large"
            value={search}
            onChange={(e) => handleSearch(e.target.value)}
          />
        </div>
        <Table dataSource={newDataSource || dataSource} columns={columns} />
      </div>
    </>
  );
}
export default index;